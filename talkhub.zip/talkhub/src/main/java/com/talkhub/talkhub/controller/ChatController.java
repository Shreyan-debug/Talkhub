package com.talkhub.talkhub.controller;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import com.talkhub.talkhub.model.ChatMessage;

@Controller
public class ChatController {

    @MessageMapping("/chat.join")
    @SendTo("/topic/public")
    public ChatMessage join(ChatMessage message) {
        message.setType(ChatMessage.MessageType.JOIN);
        message.setContent("joined the chat");
        return message;
    }

    @MessageMapping("/chat.send")
    @SendTo("/topic/public")
    public ChatMessage send(ChatMessage message) {
        message.setType(ChatMessage.MessageType.CHAT);
        return message;
    }
}
