package com.talkhub.talkhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalkhubApplicationTests {

	@Test
	void contextLoads() {
	}

}
